#ifndef GRABBERCVCAM
#define GRABBERCVCAM

#pragma once
#include "Grabber.h"

class CGrabberCVCam : public CGrabber
{
public:
	CGrabberCVCam( int width = 640, int height = 480 );
	~CGrabberCVCam( void );

	bool OpenGrabber( void );
	bool CloseGrabber( void );

	void GetFrame( void );

	void GetIplImage( IplImage * ipl_ptr );

private:
	IplImage * iplImage;

	yarp::os::Semaphore mutex_image;

public:
	static IplImage * cvcamImage;
	static yarp::os::Semaphore mutex_cvcamImage;
};

#endif GRABBERCVCAM
