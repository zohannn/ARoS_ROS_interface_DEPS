#include "GrabberCVCam.h"

#include <cvcam.h>
#include <highgui.h>

void __cdecl cvcam_callback_function( void* _image )
{
	IplImage* image = (IplImage*)_image;
	
	long size_src;
	long size_dst;
	
	CGrabberCVCam::mutex_cvcamImage.wait();
	size_src = image->height*image->widthStep;
	size_dst = CGrabberCVCam::cvcamImage->height*CGrabberCVCam::cvcamImage->widthStep;
	if( size_src != size_dst )
	{
		cvResize( image, CGrabberCVCam::cvcamImage );
	}
	else
	{
		cvCopy( image, CGrabberCVCam::cvcamImage );
	}
	CGrabberCVCam::mutex_cvcamImage.post();
};

IplImage * CGrabberCVCam::cvcamImage = cvCreateImage( cvSize( 640, 480 ), IPL_DEPTH_8U, 3 );

yarp::os::Semaphore CGrabberCVCam::mutex_cvcamImage( 1 );

CGrabberCVCam::CGrabberCVCam( int width, int height )
: CGrabber( width, height )
, mutex_image( 1 )
, iplImage( NULL )
{
}

CGrabberCVCam::~CGrabberCVCam( void )
{
}

bool CGrabberCVCam::OpenGrabber( void )
{
	int ncams = cvcamGetCamerasCount();

	if( ncams <= 0 ) return false;

    cvcamSetProperty( 0, CVCAM_PROP_ENABLE, CVCAMTRUE );
	cvcamSetProperty(0, CVCAM_PROP_CALLBACK, cvcam_callback_function );
    //cvcamSetProperty(0, CVCAM_PROP_WINDOW, &hwnd);   

    //Set Video Format Property
    VidFormat vidFmt = { nWidth, nHeight, 15.0 }; // { Width, Height, FPS }
    cvcamSetProperty( 0, CVCAM_PROP_SETFORMAT, &vidFmt );

	// Display the video format dialog
	cvcamGetProperty( 0, CVCAM_VIDEOFORMAT, NULL );

	int res;

    // Initialize camera
	res = cvcamInit();
	
	if( !res ) return false;
    
	// Start capture
	res = cvcamStart();
    
	if( res == -1 ) return false;
	
	iplImage = cvCreateImage( cvSize( nWidth, nHeight ), IPL_DEPTH_8U, 3 );
	
	return true;
}

bool CGrabberCVCam::CloseGrabber( void )
{
	// Stop capture
	cvcamStop();

	// Free resources
	cvcamExit();

	return true;
}

void CGrabberCVCam::GetFrame( void )
{
	/*
	IplImage* image;

	cvcamPause();
	
	// Get a pointer to the last frame
	cvcamGetProperty( 0, CVCAM_PROP_RAW, &image );
	
	mutex_image.wait();
	cvCopy( image, iplImage );
	mutex_image.post();

	cvcamResume();*/

	mutex_cvcamImage.wait();
	mutex_image.wait();
	cvCopy( cvcamImage, iplImage );
	//cvZero( iplImage );
	//cvShowImage( "Grabber", cvcamImage );
	mutex_image.post();
	mutex_cvcamImage.post();
}

void CGrabberCVCam::GetIplImage( IplImage * ipl_ptr )
{
	IplImage * img_aux = NULL;
	
	IplImage * the_Image = iplImage;

	//Lock the image access
	mutex_image.wait();

	if( ipl_ptr == NULL )
		ipl_ptr = cvCreateImage( cvSize( nWidth, nHeight ), IPL_DEPTH_8U, 3 );

	else
	{
		long lSize_src = iplImage->widthStep*iplImage->height;
		long lSize_dst = ipl_ptr->widthStep*ipl_ptr->height;

		if( lSize_src != lSize_dst )
		{
			//cvReleaseImage( &ipl_ptr );
			//ipl_ptr = cvCreateImage( cvSize( nWidth, nHeight ), IPL_DEPTH_8U, 3 );
			img_aux = cvCreateImage( cvSize( ipl_ptr->width, ipl_ptr->height), ipl_ptr->depth, ipl_ptr->nChannels );

			cvResize( iplImage, img_aux, CV_INTER_AREA );

			the_Image = img_aux;
		}
	}

	// Copy the captured image to the output image, flipping it if
	// the coordinate origin is not the top left
	if( the_Image->origin == IPL_ORIGIN_TL )
		cvCopy( the_Image, ipl_ptr, NULL );
	else
		cvFlip( the_Image, ipl_ptr, NULL );
	
	if( img_aux != NULL )
	{
		cvReleaseImage( &img_aux );
		img_aux = NULL;
	}
	
	//Unlock the image access
	mutex_image.post();
}